#!/bin/bash

if [[ ! -f a.out ]] ; then
    echo "ERROR, a.out missing"
    exit 0
    fi
echo "enter e for counter: "
read e
if [[ $e == "quit" ]] ; then
    exit 0
    fi

iteration=5
totalTime=0

for((i=1; i <=iteration; i++))
do
    echo "Running iteration ${i}..."
    time=`./a.out ${e}`
    echo "time taken: ${time} ms"
    totalTime=`expr $totalTime + $time`
done

echo "Average time was "`expr $totalTime / $iteration`"ms"