#ifndef HEAP_H
#define HEAP_H

#include <iostream>
#include <vector>
#include "heapNode.h"

using namespace std;
class heap{
    public:
        heap();
        heap(vector<heapNode*> v);
        ~heap();
        vector<heapNode*> v;
        int size;
        heapNode* root;
        void insert(heapNode* node);
        heapNode* deleteMin();
        void percolateUp(int index);
        void percolateDown(int index);
        void printHeap();
        string prefixCode(heapNode* root, string s);
        void compression();
        bool isLeaf(heapNode* node);
        void printTree(heapNode* root);

};

#endif
