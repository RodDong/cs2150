#include <iostream>
#include <fstream>
#include <cstdlib>
#include <vector>
#include<math.h>
#include "heap.h"

using namespace std;

int main(int argc, char** argv){
    if (argc != 2) {
        cout << "Must supply the input file name as the one and only parameter" << endl;
        exit(1);
    }

    ifstream file(argv[1]);
    if (!file.is_open()) {
        cout << "Unable to open '" << argv[1] << "' for reading" << endl;
        exit(2);
    }

    char g;
    vector<heapNode*> heapNodes;
    int hash;
    heap h = heap();
    for(int i = 0; i<108; i++){
        heapNodes.push_back(NULL);
    }
    while (file.get(g)) {
        hash = int(g)-32;
        heapNode* temp = new heapNode(g, 1);
        cout<<hash<<endl;
        if(heapNodes[hash]==NULL){
            heapNodes[hash] = temp;
        }else{
            heapNodes[hash]->frequency+=1;
        }
    }
    for(int i = 0; i<heapNodes.size(); i++){
        if(heapNodes[i]!=NULL){
            h.insert(heapNodes[i]);
        }
    }
    h.printHeap();
    h.compression();
    h.printTree(h.v[1]);
    string s;
    cout<<h.prefixCode(h.v[1], s)<<endl;
    

    // cout << "----------------------------------------" << endl;
    file.clear();
    //file.seekg(0);
    //while (file.get(g)) {
    //    cout << g;
    //}
    file.close();

    return 0;

}